document.addEventListener("DOMContentLoaded", function () {
  const cards = document.querySelectorAll(".card");

  const isElementInViewport = (el) => {
    const rect = el.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <=
        (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  };

  const handleScroll = () => {
    cards.forEach((card) => {
      if (isElementInViewport(card)) {
        card.classList.add("slide-in-left");
      }
    });
  };

  handleScroll();

  window.addEventListener("scroll", handleScroll);
  window.addEventListener("resize", handleScroll);
});



let carrosDisponiveis = {
  bacalar: ["bacalar", "bacalar", "bacalar", "bacalar", "bacalar", "bacalar", "bacalar", "bacalar", "bacalar", "bacalar"],
  gordon: ["gordon", "gordon", "gordon", "gordon", "gordon", "gordon", "gordon", "gordon", "gordon", "gordon"],
  mclaren: ["mclaren", "mclaren", "mclaren", "mclaren", "mclaren", "mclaren", "mclaren", "mclaren", "mclaren", "mclaren"],
  vayanne: ["vayanne", "vayanne", "vayanne", "vayanne", "vayanne", "vayanne", "vayanne", "vayanne", "vayanne", "vayanne"],
  tomasmo: ["tomasmo", "tomasmo", "tomasmo", "tomasmo", "tomasmo", "tomasmo", "tomasmo", "tomasmo", "tomasmo", "tomasmo"],
  czinger: ["czinger", "czinger", "czinger", "czinger", "czinger", "czinger", "czinger", "czinger", "czinger", "czinger"],
  ferrari: ["ferrari", "ferrari", "ferrari", "ferrari", "ferrari", "ferrari", "ferrari", "ferrari", "ferrari", "ferrari"],
  monza: ["monza", "monza", "monza", "monza", "monza", "monza", "monza", "monza", "monza", "monza"],
  venom: ["venom", "venom", "venom", "venom", "venom", "venom", "venom", "venom", "venom", "venom"],
  drako: ["drako", "drako", "drako", "drako", "drako", "drako", "drako", "drako", "drako", "drako"],
  koeniggseg: ["koeniggseg", "koeniggseg", "koeniggseg", "koeniggseg", "koeniggseg", "koeniggseg", "koeniggseg", "koeniggseg", "koeniggseg", "koeniggseg"],
  pagani: ["pagani", "pagani", "pagani", "pagani", "pagani", "pagani", "pagani", "pagani", "pagani", "pagani"]
};


let carrosVendidos = [];

function comprarCarro(modelo) {
  let estoque = document.getElementById(modelo).textContent.split(": ")[1];
  estoque = parseInt(estoque);

  if (estoque > 0) {
    document.getElementById(modelo).textContent = `Estoque: ${--estoque}`;
    let carroComprado = carrosDisponiveis[modelo].shift();
    carrosVendidos.push(carroComprado);

    console.log("Carros vendidos: " + carrosVendidos.length);
    console.log(`${modelo} Disponíveis: ` + carrosDisponiveis[modelo].length);
  } else {
    document.getElementById(modelo).textContent = `Estoque: Esgotado!!`
   
    let imagem = document.getElementById(`${modelo}-img`);
    imagem.style.filter = "grayscale(100%)";

    // Esconder o botão de compra
    let botao = document.getElementById(`${modelo}-buy-button`);
    botao.style.display = "none";

  }
}






